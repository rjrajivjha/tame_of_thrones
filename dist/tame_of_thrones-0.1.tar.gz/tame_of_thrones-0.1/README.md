**Ruler, Tame of Thrones**

I am using a challenge from Geektrust platform to showcase, how I arrive to a solution, given a coding problem.

Problem File : `Geektrust_in_tameofthrones_python.pdf`

*How to find if SPACE kingdom can become a ruler of universe:*

`python -m geektrust <absolute_path_to_input_file>`

Sample Input file : tame_of_thrones_1.txt