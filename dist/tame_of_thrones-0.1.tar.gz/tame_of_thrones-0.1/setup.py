from setuptools import setup

setup(name='tame_of_thrones',
      version='0.1',
      description='Tame of Thrones',
      url='http://rjrajivjha.github.io',
      author='Rajiv Jha',
      author_email='fork.rajiv@gmail.com',
      license='GPL',
      packages=['tame_of_thrones'],
      zip_safe=False,
)